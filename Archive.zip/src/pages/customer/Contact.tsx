const Home = () => {
    return (
        <div>
            <h1>Contact Page</h1>
        </div>
    )
}
export default Home;